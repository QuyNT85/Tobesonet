import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import * as React from "react";
import SettingScreen from '../src/screens/Setting';
import MyAccount from "../src/screens/MyAccount";
import EditAccountScreen from '../src/screens/EditAccount';
import SidebarmenuScreen from '../src/screens/Sidebarmenu';
import LoginScreen from "../src/screens/Login";
import SignUpScreen from "../src/screens/Signup";
import Dropdown from "../src/screens/drop";
import Mystack from "./navigators/stacknavigators";

const Stack= createNativeStackNavigator();
function Main() {
    return (
        // <NavigationContainer>
        //    <Stack.Navigator initialRouteName="Drop" screenOptions={{headerShown:false}}>
        //         <Stack.Screen name="Login" component={LoginScreen}/>
        //         <Stack.Screen name="SignUp" component={SignUpScreen}/>
        //         <Stack.Screen name="MyAccount" component={MyAccount}/>
        //         <Stack.Screen name="Setting" component={SettingScreen}/>
        //         <Stack.Screen name="EditAcount" component={EditAccountScreen}/>
        //         <Stack.Screen name="SideBarMenu" component={SidebarmenuScreen}/>
        //         <Stack.Screen name="Drop" component={Dropdown}/>
        //    </Stack.Navigator>
        // </NavigationContainer>
        <Mystack/>
    )
}
export default Main;